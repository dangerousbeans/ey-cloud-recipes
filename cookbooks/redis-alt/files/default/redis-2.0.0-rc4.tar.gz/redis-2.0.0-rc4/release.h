#define REDIS_GIT_SHA1 "655f79a9"
#define REDIS_GIT_DIRTY "       0"
